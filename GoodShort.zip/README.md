# FakePurchase
Simula compras in-app interceptando SKPaymentQueue no app GoodShort.

Compatível com arm64 / arm64e.  
Pode ser usado via Theos localmente ou GitHub Actions.
